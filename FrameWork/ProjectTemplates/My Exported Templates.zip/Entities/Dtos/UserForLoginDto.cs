﻿using Framework.$safeprojectname$;

namespace $safeprojectname$.Dtos
{
   public class UserForLoginDto:IDto
    {
        public string Email { get; set; }
        public string Password { get; set; }
    }
}
