﻿using $safeprojectname$.Abstract;
using $safeprojectname$.Concrete.EntityFramework.Contexts;
using Entities.Concrete;
using Framework.$safeprojectname$.EntityFramework;

namespace $safeprojectname$.Concrete.EntityFramework
{
   public class EfCategoryDal : EfRepositoryBase<Category, NorthwindContext>, ICategoryDal
    {
    }
}
