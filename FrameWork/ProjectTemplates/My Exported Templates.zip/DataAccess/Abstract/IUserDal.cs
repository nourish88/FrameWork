﻿using System.Collections.Generic;
using Entities.Concrete;
using Framework.$safeprojectname$;
using Framework.Entities.Concrete;

namespace $safeprojectname$.Abstract
{
 public interface    IUserDal:IEntityRepository<User>
 {
     List<OperationClaim> GetClaims(User user);
 }
}
