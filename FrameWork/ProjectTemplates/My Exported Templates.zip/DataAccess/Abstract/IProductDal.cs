﻿using Entities.Concrete;
using Framework.$safeprojectname$;

namespace $safeprojectname$.Abstract
{ //crud işlemlerini bu yapar.. business değil.
    public interface IProductDal:IEntityRepository<Product>
    {
    }
}
