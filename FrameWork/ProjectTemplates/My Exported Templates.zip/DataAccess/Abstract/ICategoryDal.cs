﻿using System;
using System.Collections.Generic;
using System.Text;
using Entities.Concrete;
using Framework.$safeprojectname$;

namespace $safeprojectname$.Abstract
{
    public interface ICategoryDal:IEntityRepository<Category>
    {
      
    }
}
