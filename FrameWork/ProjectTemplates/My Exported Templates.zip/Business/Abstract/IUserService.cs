﻿using Entities.Concrete;
using System.Collections.Generic;
using Framework.Entities.Concrete;

namespace $safeprojectname$.Abstract
{
    public interface IUserService
    {
        List<OperationClaim> GetClaims(User user);
        void Add(User user);
        User GetByMail(string email);

    }
}
