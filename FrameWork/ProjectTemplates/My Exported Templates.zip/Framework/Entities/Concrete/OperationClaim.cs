﻿namespace $safeprojectname$.Entities.Concrete
{//roller
    public   class OperationClaim:IEntity
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
