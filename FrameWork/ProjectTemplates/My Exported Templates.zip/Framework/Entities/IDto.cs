﻿namespace $safeprojectname$.Entities
{
    public interface IDto
    {
    }
}
