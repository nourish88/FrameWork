﻿namespace $safeprojectname$.Entities
{
    public   interface IEntity
    {
    }
}
