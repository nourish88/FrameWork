﻿using $safeprojectname$.CrossCuttingConcerns.Logging.Log4Net;

namespace $safeprojectname$.CrossCuttingConcerns.Logging.Loggers
{
    public class FileLogger : LoggerServiceBase
    {
        public FileLogger() : base("JsonFileLogger")
        {
        }
    }
}
