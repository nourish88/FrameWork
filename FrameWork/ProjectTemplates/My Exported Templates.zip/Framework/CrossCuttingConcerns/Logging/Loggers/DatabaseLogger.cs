﻿using $safeprojectname$.CrossCuttingConcerns.Logging.Log4Net;

namespace $safeprojectname$.CrossCuttingConcerns.Logging.Loggers
{
    public class DatabaseLogger : LoggerServiceBase
    {
        public DatabaseLogger() : base("DatabaseLogger")
        {
        }
    }
}
