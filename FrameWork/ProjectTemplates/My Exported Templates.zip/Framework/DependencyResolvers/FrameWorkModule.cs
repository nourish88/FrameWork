﻿using System;
using System.Diagnostics;
using System.Reflection;
using AutoMapper;
using $safeprojectname$.CrossCuttingConcerns.Caching;
using $safeprojectname$.CrossCuttingConcerns.Caching.MemoryCache;
using $safeprojectname$.Utilities.IoC;
using $safeprojectname$.Utilities.Mappings;

using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$.DependencyResolvers
{
    public class FrameWorkModule:IFrameWorkModule
    {// tüm resolve işlemlerini tek ir merkezden yönetiyoruz. Gayet güzel.
        public void Load(IServiceCollection services)
        {
           
            services.AddMemoryCache();
            services.AddSingleton<ICacheManager, MemoryCacheManager>();
            services.AddSingleton<Stopwatch>();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
         
        }
    }
}
