﻿using System;
using System.Transactions;
using Castle.DynamicProxy;
using $safeprojectname$.Utilities.Interceptors.Autofac;

namespace $safeprojectname$.Aspects.Autofac.Transcation
{
    public class TransactionScopeAspect : MethodInterception
    {
        public override void Intercept(IInvocation invocation)
        {
            using (var transactionScope = new TransactionScope())
            {
                try
                {
                    invocation.Proceed();
                    transactionScope.Complete();
                }
                catch (Exception e)
                {
                    transactionScope.Complete();
                    throw;
                }
            }
        }
    }
}
