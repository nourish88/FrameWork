﻿using System;
using System.Collections.Generic;
using System.Text;
using Castle.DynamicProxy;


namespace $safeprojectname$.Utilities.Interceptors.Autofac
{//castle dynamic proxy

    [AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true, Inherited = true)]
    public class MethodInterceptionBaseAttribute : Attribute, IInterceptor
    {
        public int Priority { get; set; }
        public virtual void Intercept(IInvocation invocation)
        {

        }
    }
}
