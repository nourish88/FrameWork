﻿using System.Collections.Generic;
using $safeprojectname$.Entities.Concrete;

namespace $safeprojectname$.Utilities.Security.JWT
{
    public interface ITokenHelper
    {
        AccessToken CreateToken(User user,List<OperationClaim> operationClaims);
    }
}
