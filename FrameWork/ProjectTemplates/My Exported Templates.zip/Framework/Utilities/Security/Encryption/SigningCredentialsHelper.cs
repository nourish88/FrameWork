﻿using Microsoft.IdentityModel.Tokens;

namespace $safeprojectname$.Utilities.Security.Encryption
{
    public class SigningCredentialsHelper
    {
        public static SigningCredentials CreaterSigningCredentials(SecurityKey securityKey)
        {

        return new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256Signature);

        }
    }
}
