﻿using Microsoft.Extensions.DependencyInjection;

namespace $safeprojectname$.Utilities.IoC
{
    public interface IFrameWorkModule
  {
      void Load(IServiceCollection serviceCollection);
  }
}
